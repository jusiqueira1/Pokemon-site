// let pokeHistory = [];


// const botaogerar = document.querySelector('.a-botao-1');
// const botaoBatalha = document.querySelector('.a-botao-2');


// botaogerar.addEventListener('click', async () => {
//     const start = Date.now();
//     await getPokemon();

// })

// botaoBatalha.addEventListener('click', () => {
//     battlePokemon();
// })


// const getPokemon = async () => {
//     const randomNumberOne = getUniqueNumber(pokeHistory, 807) + 1;
//     const randomNumberTwo = getUniqueNumber(pokeHistory, 807) + 1;

//     const pokeDataArr = await pokemonDataSync(randomNumberOne, randomNumberTwo);
//     await renderPokemonSync(pokeDataArr);
// }

// const pokemonDataSync = async (num1, num2) => {
//     let pokeDataArr = [];
//     const pokemonOne = await makeApiCall(num1);
//     const pokemonTwo = await makeApiCall(num2);

//     pokeDataArr.push(pokemonOne);
//     pokeDataArr.push(pokemonTwo);

//     return await pokeDataArr;
// }

// const renderPokemonSync = (pokeDataArr) => {
//     displayPokemonData(pokeDataArr[0]);
//     displayPokemonData(pokeDataArr[1]);
// }

// // Aqui é a variavel para receber novo pokemon.
// const getNewPokemon = async () => {
//     document.querySelector('.data').innerHTML = '';
//     const start2 = Date.now();
//     await getPokemon();
// }

// // Aqui ocorre a batalha dos pokemons ,sendo colocado sua história,nome e recebe defesas se número for menor que 5.
// const battlePokemon = () => {
//     const randomNumber = Math.random();
//     const battleResult = document.createElement('p');
//     const battleHistory = document.querySelector('#history');
//     const pokemonOne = document.querySelectorAll('.pokemon-name')[0].innerText;
//     const pokemonTwo = document.querySelectorAll('.pokemon-name')[1].innerText;

//     if (randomNumber < .5) {
//         battleResult.innerText = `${pokemonOne} defeated ${pokemonTwo}`;
//         battleHistory.prepend(battleResult);
//         getNewPokemon();
//     } else {
//         battleResult.innerText = `${pokemonTwo} defeated ${pokemonOne}`
//         battleHistory.prepend(battleResult);
//         getNewPokemon();
//     }
// }

// // Aqui a variável recebe o histórico da batalha
// const getUniqueNumber = (history, max) => {
//     const ranNum = Math.floor(Math.random() * max);
//     if (!history.includes(ranNum)) {
//         history.push(ranNum);
//         return ranNum;
//     } else {
//         return getUniqueNumber(history, max);
//     }
// }

// const makeApiCall = async (ranNum) => await axios.get(`https://pokeapi.co/api/v2/pokemon/${ranNum}`);


// const displayPokemonData = async (data) => {
//     const name = document.querySelector('.h4-nome');
//     const img = document.querySelector('.imagem-1');


//     name.innerText = data.data.name;
//     img.src = data.data.sprites.front_shiny;


//     if (data.data.sprites.back_shiny != null) {
//         img.addEventListener('mouseover', () => {
//             img.style.transition = '.5s ease';
//             img.src = data.data.sprites.back_shiny;
//         })
//     }
    
//     img.addEventListener('mouseleave', () => {
//         img.style.transition = '.5s ease';
//         img.src = data.data.sprites.front_shiny;
//     })

// };
const gerarAleatorioBtn = document.getElementById('a-botao-1');
const pokemonContainer = document.getElementById('pokemonContainer');

gerarAleatorioBtn.addEventListener('click', async () => {
  const pokemonData = await getPokemonData();
  renderPokemon(pokemonData);
});

const getRandomPokemonId = () => Math.floor(Math.random() * 807) + 1; // Gera um número aleatório entre 1 e 898 (total de Pokémon na API)

const getPokemonData = async () => {
  const pokeDataArr = [];
  for (let i = 0; i < 2; i++) {
    const randomPokemonId = getRandomPokemonId();
    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${randomPokemonId}`);
    const data = await response.json();
    pokeDataArr.push(data);
  }
  return pokeDataArr;
};

const renderPokemon = (pokemonData) => {
  pokemonContainer.innerHTML = '';
  pokemonData.forEach(pokemon => {
    const pokemonElement = document.createElement('div');
    pokemonElement.innerHTML = `
      <h2>${pokemon.name}</h2>
      <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}" />
    `;
    pokemonContainer.appendChild(pokemonElement);
  });
};





document.addEventListener('DOMContentLoaded', () => {
    const gerarBatalhaBtn = document.getElementById('a-botao-1');
    const cards = document.querySelectorAll('.card');
  
    class Pokemon {
      constructor(nome, tipo, ataque, defesa, sprite) {
        this.nome = nome;
        this.tipo = tipo;
        this.ataque = ataque;
        this.defesa = defesa;
        this.vida = 100; // Vida inicial de todo pokémon
        this.sprite = sprite; 
      }
  
      atacar(outroPokemon) {
        const dano = this.ataque - outroPokemon.defesa;
        outroPokemon.vida -= dano > 0 ? dano : 0;
        return dano > 0 ? dano : 0;
      }
    }
  
    const fetchPokemon = async () => {
      const response1 = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemon}`); // Exemplo de requisição para o Pokémon com ID 1 (Pikachu)
      const data1 = await response1.json();
      const pokemon1 = new Pokemon(
        data1.name,
        data1.types[0].type.name,
        data1.stats[1].base_stat,
        data1.stats[2].base_stat,
        data1.sprites.front_default
      );
  
      const response2 = await fetch('https://pokeapi.co/api/v2/pokemon/4'); // Exemplo de requisição para o Pokémon com ID 4 (Charmander)
      const data2 = await response2.json();
      const pokemon2 = new Pokemon(
        data2.name,
        data2.types[0].type.name,
        data2.stats[1].base_stat,
        data2.stats[2].base_stat,
        data2.sprites.front_default
      );
  
      return [pokemon1, pokemon2];
    };
  
    const atualizarStatus = (card, pokemon) => {
      const vidaPokemon = card.querySelector('.h4-nome');
      vidaPokemon.textContent = `${pokemon.nome} (${pokemon.vida} HP)`;
  
      const imagemPokemon = card.querySelector('.imagem-1');
      imagemPokemon.src = pokemon.sprite; 
    };
  
    const realizarBatalha = async () => {
      const [pikachu, charmander] = await fetchPokemon();
  
      const danoPikachu = pikachu.atacar(charmander);
      const danoCharmander = charmander.atacar(pikachu);
  
      atualizarStatus(cards[0], pikachu);
      atualizarStatus(cards[1], charmander);
  
      alert(`${pikachu.nome} atacou ${charmander.nome} e causou ${danoPikachu} de dano!`);
      alert(`${charmander.nome} atacou ${pikachu.nome} e causou ${danoCharmander} de dano!`);
  
      if (pikachu.vida <= 0 && charmander.vida <= 0) {
        alert('A batalha termina em empate!');
      } else if (pikachu.vida <= 0) {
        alert(`${charmander.nome} vence a batalha!`);
      } else if (charmander.vida <= 0) {
        alert(`${pikachu.nome} vence a batalha!`);
      }
    };
  
    gerarBatalhaBtn.addEventListener('click', realizarBatalha);
  });
  