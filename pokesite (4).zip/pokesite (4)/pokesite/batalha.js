document.addEventListener('DOMContentLoaded', () => {
  const gerarBatalhaBtn = document.getElementById('a-botao-1');
  const cards = document.querySelectorAll('.card');

  class Pokemon {
    constructor(nome, tipo, ataque, defesa, sprite) {
      this.nome = nome;
      this.tipo = tipo;
      this.ataque = ataque;
      this.defesa = defesa;
      this.vida = 100;
      this.sprite = sprite;
    }

    atacar(outroPokemon) {
      const dano = this.ataque - outroPokemon.defesa;
      outroPokemon.vida -= dano > 0 ? dano : 0;
      return dano > 0 ? dano : 0;
    }
  }

  const atualizarStatus = (card, pokemon) => {
    const vidaPokemon = card.querySelector('.h4-nome');
    vidaPokemon.textContent = `${pokemon.nome} (${pokemon.vida} HP)`;

    const imagemPokemon = card.querySelector('.imagem-1');
    imagemPokemon.src = pokemon.sprite;
  };

  const fetchRandomPokemon = async () => {
    const randomIds = Array.from({ length: 2 }, () => Math.floor(Math.random() * 500) + 1);
    const responses = await Promise.all(randomIds.map(id => fetch(`https://pokeapi.co/api/v2/pokemon/${id}`)));
    const data = await Promise.all(responses.map(response => response.json()));

    const pokemons = data.map(pokemonData => new Pokemon(
      pokemonData.name,
      pokemonData.types[0].type.name,
      pokemonData.stats[1].base_stat,
      pokemonData.stats[2].base_stat,
      pokemonData.sprites.front_default
    ));

    return pokemons;
  };

  const atualizarCardsComPokemon = (pokemon1, pokemon2) => {
    atualizarStatus(cards[0], pokemon1);
    atualizarStatus(cards[1], pokemon2);
  };

  const realizarBatalha = async () => {
    const [pokemon1, pokemon2] = await fetchRandomPokemon();
    atualizarCardsComPokemon(pokemon1, pokemon2);

    const danopokemon1 = pokemon1.atacar(pokemon2);
    const danopokemon2 = pokemon2.atacar(pokemon1);

    atualizarStatus(cards[0], pokemon1);
    atualizarStatus(cards[1], pokemon2);

    alert(`${pokemon1.nome} atacou ${pokemon2.nome} e causou ${danopokemon1} de dano!`);
    alert(`${pokemon2.nome} atacou ${pokemon1.nome} e causou ${danopokemon2} de dano!`);

    if (pokemon1.vida <= 0 && pokemon2.vida <= 0) {
      alert('A batalha termina em empate!');
    } else if (pokemon1.vida <= 0) {
      alert(`${pokemon2.nome} vence a batalha!`);
    } else if (pokemon2.vida <= 0) {
      alert(`${pokemon1.nome} vence a batalha!`);
    }
  };

  gerarBatalhaBtn.addEventListener('click', realizarBatalha);
});
